#include <at89c5131.h>
#include "lcd.h"
#include "spi.h"

unsigned int a1;
unsigned int a2;
unsigned int a3;
unsigned int b1;
unsigned int b2;
unsigned int b3;
unsigned int result;

extern void MAC();
unsigned char data point_a1 _at_ 0x70;
unsigned char data point_a2 _at_ 0x71;
unsigned char data point_a3 _at_ 0x72;
unsigned char data point_b1 _at_ 0x73;
unsigned char data point_b2 _at_ 0x74;
unsigned char data point_b3 _at_ 0x75;
unsigned char data point_result _at_ 0x78;

unsigned char triala1[] = {'0', '0', '0', '0', '0', '\0'};
unsigned char triala2[] = {'0', '0', '0', '0', '0', '\0'};
unsigned char triala3[] = {'0', '0', '0', '0', '0', '\0'};
unsigned char trialb1[] = {'0', '0', '0', '0', '0', '\0'};
unsigned char trialb2[] = {'0', '0', '0', '0', '0', '\0'};
unsigned char trialb3[] = {'0', '0', '0', '0', '0', '\0'};
unsigned char trials[] = {'0', '0', '0', '0', '0', '\0'};

unsigned char sum_string[] = {"Total: "};

unsigned int check_prime (unsigned int c)
{
	unsigned int i;
	
	if (c == 1)
	{
		return 0;
	}
	if (c == 2)
	{
		return 1;
	}
	
	if (c % 2 == 0)
	{
		return 0;
	}
	
	for (i = 3; i * i <= c; i+= 2)
	{
		if (c % i == 0)
		{
			return 0;
		}
	}
	
	return 1;
}

void main (void)
{
	
	lcd_init();
	spi_init();
	
	//Sending 0(Hopefully shouldn't affect)
	a1 = spi_single_byte(8);
	point_a1 = (unsigned char)a1;
	
	//Sending 0(Hopefully shouldn't affect)
	a2 = spi_single_byte(8);
	point_a2 = (unsigned char)a2;
	
	//Sending 0(Hopefully shouldn't affect)
	a3 = spi_single_byte(8);
	point_a3 = (unsigned char)a3;
	
	//Sending 0 again(Hopefully shouldn't affect again)
	b1 = spi_single_byte(8);
	point_b1 = (unsigned char)b1;
	
	//Sending 0 again(Hopefully shouldn't affect again)
	b2 = spi_single_byte(8);
	point_b2 = (unsigned char)b2;
	
	//Sending 0 again(Hopefully shouldn't affect again)
	b3 = spi_single_byte(8);
	point_b3 = (unsigned char)b3;
	
	MAC();
	result = point_result;
	
	int_to_string(a1, triala1);
	int_to_string(a2, triala2);
	int_to_string(a3, triala3);
	int_to_string(b1, trialb1);
	int_to_string(b2, trialb2);
	int_to_string(b3, trialb3);
	int_to_string(result, trials);
	
	result = check_prime(result);
	
	//Sending the Result(Please Work for god's sake)
	spi_single_byte(result);
	
	lcd_cmd(0x80);
	lcd_write_char(triala1[4]);
	lcd_write_char('*');
	lcd_write_char(trialb1[4]);
	lcd_write_char('+');
	lcd_write_char(triala2[4]);
	lcd_write_char('*');
	lcd_write_char(trialb2[4]);
	lcd_write_char('+');
	lcd_write_char(triala3[4]);
	lcd_write_char('*');
	lcd_write_char(trialb3[4]);
	
	lcd_cmd(0xC0);
	lcd_write_string(sum_string);
	lcd_write_char(trials[2]);
	lcd_write_char(trials[3]);
	lcd_write_char(trials[4]);
	
	while (1);
	
}
