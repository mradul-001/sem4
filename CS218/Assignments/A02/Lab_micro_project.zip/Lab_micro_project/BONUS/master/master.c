#include <at89c5131.h>
#include "lcd.h"
#include "spi.h"
#include "serial.h"

unsigned char ir;

unsigned int a1;
unsigned int a2;
unsigned int a3;
unsigned int b1;
unsigned int b2;
unsigned int b3;

unsigned int result;
unsigned int lcd_output;

code unsigned char prime_lcd[] = "PRIME";
code unsigned char not_prime_lcd[] = "NOT PRIME";

code unsigned char triala1[] = {'0', '0', '0', '0', '0', '\0'};
code unsigned char triala2[] = {'0', '0', '0', '0', '0', '\0'};
code unsigned char triala3[] = {'0', '0', '0', '0', '0', '\0'};
code unsigned char trialb1[] = {'0', '0', '0', '0', '0', '\0'};
code unsigned char trialb2[] = {'0', '0', '0', '0', '0', '\0'};
code unsigned char trialb3[] = {'0', '0', '0', '0', '0', '\0'};
code unsigned char trials[] = {'0', '0', '0', '0', '0', '\0'};



void main(void)
{
	
	uart_init();
	spi_init();
  lcd_init();
	
	msdelay(1000);
	
	//Sending numbers from UART
	transmit_string("Input the 1st number\r\n");
	ir = receive_char();
	a1 = (int)(ir) - 48;
	
	transmit_string("Input the 2nd number\r\n");
	ir = receive_char();
	a2 = (int)(ir) - 48;
	
	transmit_string("Input the 3rd number\r\n");
	ir = receive_char();
	a3 = (int)(ir) - 48;
	
	transmit_string("Input the 1st multiplier\r\n");
	ir = receive_char();
	b1 = (int)(ir) - 48;
	
	transmit_string("Input the 2nd multiplier\r\n");
	ir = receive_char();
	b2 = (int)(ir) - 48;
	
	transmit_string("Input the 3rd multiplier\r\n");
	ir = receive_char();
	b3 = (int)(ir) - 48;
	
	//Start Delay
	msdelay(50);
	
	//Sending the First Number
	result = spi_single_byte(a1);
	
	int_to_string(result, triala1);
	lcd_cmd(0x80);
	//lcd_write_char(triala1[4]);
	
	msdelay(50);
	
	//lcd_write_char(' ');
	//Sending the First Number
	result = spi_single_byte(a2);
	
	int_to_string(result, triala2);
	lcd_cmd(0x80);
	//lcd_write_char(triala2[4]);
	
	msdelay(50);
	
	//lcd_write_char(' ');
	//Sending the First Number
	result = spi_single_byte(a3);
	
	int_to_string(result, triala3);
	lcd_cmd(0x80);
	//lcd_write_char(triala3[4]);
	
	msdelay(50);
	
	//lcd_write_char(' ');
	
	//Sending the Second Number
	result = spi_single_byte(b1);
	
	int_to_string(result, trialb1);
	//lcd_cmd(0x80);
	//lcd_write_char(trialb1[4]);
	
	msdelay(50);
	
	//lcd_write_char(' ');
	//Sending the Second Number
	result = spi_single_byte(b2);
	
	int_to_string(result, trialb2);
	//lcd_cmd(0x80);
	//lcd_write_char(trialb2[4]);
	
	msdelay(50);
	
	//lcd_write_char(' ');
	//Sending the Second Number
	result = spi_single_byte(b3);
	
	int_to_string(result, trialb3);
	//lcd_cmd(0x80);
	//lcd_write_char(trialb3[4]);
	
	//Waiting for computation
	msdelay(1000);
	
	//The Third Cycle(Should Hopefully get the result)
	lcd_output = spi_single_byte(0);
	lcd_output = (unsigned int)(lcd_output);
	
	int_to_string(lcd_output, trials);
	
	lcd_cmd(0x80);
	
	if (lcd_output == 0)
	{
		lcd_write_string(not_prime_lcd);
	}
	else
	{
		lcd_write_string(prime_lcd);
	}
	
	while (1);
	
}
