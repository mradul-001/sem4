/**********************************************************
EE337: ADC IC MCP3008 interfacing with pt-51
(1) Complete spi_init() function from spi.h 

***********************************************************/

#include <at89c5131.h>
#include "lcd.h"																				//Driver for interfacing lcd 
#include "spi.h"																		//Driver for interfacing ADC ic MCP3008


char lcd_string[6]={0,0,0,0,0,'\0'};
char first_number[6]={0,0,0,0,0,'\0'};
char second_number[6]={0,0,0,0,0,'\0'};

void main(void)
{
	unsigned int i;
	unsigned int x, y, sum = 0;
  spi_init();																					
  lcd_init();
		y = spi_trx(0);
		msdelay(100);
		x = spi_trx(0);
    sum = x + y;
		for(i = 2; i< sum; i++){
			if(sum%i ==0){
				break;
			}
		}
/*		msdelay(100);*/
		if(sum == i){
			spi_trx(1);
		}
		else{
			spi_trx(0);
		}	
		lcd_cmd(0x80);
		lcd_write_string("x:");
		int_to_string(x, first_number);
		lcd_write_string(first_number);
		lcd_write_string(",y:");
		int_to_string(y, second_number);
		lcd_write_string(second_number);
		lcd_cmd(0xC0);
		int_to_string(sum, lcd_string);
		lcd_write_string(lcd_string);
		msdelay(500);
		while(1);
}