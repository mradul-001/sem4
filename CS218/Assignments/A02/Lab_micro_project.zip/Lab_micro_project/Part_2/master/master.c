#include <at89c5131.h>
#include "lcd.h"
#include "spi.h"
#include "serial.h"

unsigned char ir;

unsigned int a;
unsigned int b;

unsigned int result;
unsigned int lcd_output;

code unsigned char prime_lcd[] = "PRIME";
code unsigned char not_prime_lcd[] = "NOT PRIME";

code unsigned char trial[] = {'0', '0', '0', '0', '0', '\0'};
code unsigned char triala[] = {'0', '0', '0', '0', '0', '\0'};
code unsigned char trialb[] = {'0', '0', '0', '0', '0', '\0'};



void main(void)
{
	
	uart_init();
	spi_init();
  lcd_init();
	
	msdelay(1000);
	
	//Sending numbers from UART
	transmit_string("Input the 1st number\r\n");
	ir = receive_char();
	a = (int)(ir) - 48;
	
	transmit_string("Input the 2nd number\r\n");
	ir = receive_char();
	b = (int)(ir) - 48;
	
	//Start Delay
	msdelay(50);
	
	//Sending the First Number
	result = spi_single_byte(a);
	
	int_to_string(result, triala);
	lcd_cmd(0x80);
	//lcd_write_char(triala[4]);
	
	//lcd_write_char(' ');
	
	msdelay(50);
	
	//Sending the Second Number
	result = spi_single_byte(b);
	
	int_to_string(result, trialb);
	//lcd_cmd(0x80);
	//lcd_write_char(trialb[4]);
	
	//lcd_write_char(' ');
	
	//Waiting for computation
	msdelay(1000);
	
	//The Third Cycle(Should Hopefully get the result)
	lcd_output=spi_single_byte(0);
	lcd_output=(unsigned int)(lcd_output);
	
	lcd_cmd(0x80);
	
	if (lcd_output == 0)
	{
		lcd_write_string(not_prime_lcd);
	}
	else
	{
		lcd_write_string(prime_lcd);
	}
	
	while (1);
	
}
